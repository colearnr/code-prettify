PR.registerLangHandler(PR.createSimpleLexer([["com",/^#[^\n\r]*/,null,"#"],["pln",/^\s+/,null," \t\r\n"]],[["pln",/^\w+/]]),["config","conf"]);
